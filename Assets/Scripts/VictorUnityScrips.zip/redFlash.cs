﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class redFlash : MonoBehaviour
{
    public int numFlashes;
    public float timeBetweenFlash;
    public Color flashColor = Color.red;
    RawImage RedImage;
    private void Start()
    {
        RedImage = GetComponent<RawImage>();

        StartCoroutine(Flash());
    }
    private void OnEnable()
    {
        StartCoroutine(Flash());
    }
    IEnumerator Flash()
    {
        // save the InputField.textComponent color
        Color defaultColor = RedImage.color;
        for (int i = 0; i < numFlashes; i++)
        {
            // if the current color is the default color - change it to the flash color
            if (RedImage.color == defaultColor)
            {
                RedImage.color = flashColor;
            }
            else // otherwise change it back to the default color
            {
                RedImage.color = defaultColor;
            }
            yield return new WaitForSeconds(timeBetweenFlash);
        }
        gameObject.SetActive(false); // magic door closes - remove object
        yield return new WaitForSeconds(1);
    }
}
