﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chest : MonoBehaviour
{
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag == "Player" && Input.GetButtonDown("Use/Interact") && this.closed)
        {
            this.closed = false;
            GameObject gameObject = UnityEngine.Object.Instantiate<GameObject>(this.item, base.transform.position, base.transform.rotation);
            gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0f, 5f);
            base.GetComponent<SpriteRenderer>().sprite = this.openedSprite;
        }
    }

    public GameObject item;

    public bool closed = true;

    public Sprite openedSprite;
}
