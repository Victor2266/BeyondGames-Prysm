﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class projectileController : MonoBehaviour
{

    public int DMG;

    private Rigidbody2D rb2d;

    public bool Primed = true;

    public GameObject pop;
    public GameObject InitialPop;

    private void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();

        Vector3 popPosition = new Vector3(transform.position.x, transform.position.y + .05f, InitialPop.transform.position.z);
        Instantiate(InitialPop, popPosition, transform.rotation);
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "enemy")
        {
            collision.gameObject.SendMessage("TakeDamage", DMG);
            if (Primed)
            {
                this.gameObject.SetActive(false);
                GameObject gameObject = Instantiate(pop, transform.position, transform.rotation);
                Primed = false;
            }
        }
        if (collision.gameObject.tag == "boss")
        {
            collision.gameObject.SendMessage("TakeDamage", DMG / 10);
        }
        if (collision.gameObject.tag == "CritBox")
        {
            collision.gameObject.SendMessage("TakeDamage", DMG * 2);
            collision.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(rb2d.velocity.x * 10f, rb2d.velocity.y * 4f);
            if (Primed)
            {
                gameObject.SetActive(false);
                GameObject gameObject2 = Instantiate(pop, transform.position, transform.rotation);
                Primed = false;
            }
        }
    }
}