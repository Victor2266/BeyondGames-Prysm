﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthBarHealth : MonoBehaviour
{
    public float health;
}
