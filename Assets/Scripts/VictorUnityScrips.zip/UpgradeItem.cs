﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class UpgradeItem : MonoBehaviour
{
    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            if (UnlocksCharging)
            {
                PlayerController.Chargeable[UnlockingWeapon - 1] = UnlockingWeapon;
                PlayerController.Chargeable[UnlockingWeapon + 7 - 1] = UnlockingWeapon + 7;
            }
            if (UnlockWeapon)
            {
                if (UnlockingWeapon == 1)
                {
                    Weapons.GetComponent<WeaponUI>().WeaponRedUI.SetActive(true);
                }
                else if (UnlockingWeapon == 2)
                {
                    Weapons.GetComponent<WeaponUI>().WeaponOrangeUI.SetActive(true);
                }
                else if (UnlockingWeapon == 3)
                {
                    Weapons.GetComponent<WeaponUI>().WeaponYellowUI.SetActive(true);
                }
                else if (UnlockingWeapon == 4)
                {
                    Weapons.GetComponent<WeaponUI>().WeaponGreenUI.SetActive(true);
                }
                else if (UnlockingWeapon == 5)
                {
                    Weapons.GetComponent<WeaponUI>().WeaponBlueUI.SetActive(true);
                }
                else if (UnlockingWeapon == 6)
                {
                    Weapons.GetComponent<WeaponUI>().WeaponIndigoUI.SetActive(true);
                }
                else if (UnlockingWeapon == 7)
                {
                    Weapons.GetComponent<WeaponUI>().WeaponVioletUI.SetActive(true);
                }
            }
            gameObject.SetActive(false);
            UnlockedText.SetActive(true);
            Image.SetActive(true);
        }
    }

    public int amount;

    public GameObject UnlockedText;

    public GameObject Image;

    public int UnlockingWeapon;

    public GameObject Weapons;

    public bool UnlocksCharging;

    public bool UnlockWeapon;
}