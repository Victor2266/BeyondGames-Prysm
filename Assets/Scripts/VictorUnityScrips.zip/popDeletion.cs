﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class popDeletion : MonoBehaviour
{

    // Use this for initialization
    void Update()
    {
        if (gameObject.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("popped"))
        {
            Destroy(gameObject);
        }
        //Destroy(gameObject, this.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).length + delay);
    }
}
