﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DelayedCameraController : MonoBehaviour
{
    private void Start()
    {
        if (!this.notTrackingPlayer)
        {
            this.player = GameObject.FindGameObjectWithTag("Player");
        }
        base.StartCoroutine(this.DelayCamera(this.delay));
    }

    private void FixedUpdate()
    {
        if (this.active)
        {
            float x = Mathf.SmoothDamp(base.transform.position.x, this.player.transform.position.x + this.offsetX, ref this.velocity.x, this.smoothTimeX);
            float num = Mathf.SmoothDamp(base.transform.position.y, this.player.transform.position.y + this.offsetY, ref this.velocity.y, this.smoothTimeY);
            base.transform.position = new Vector3(x, num + 0.5f, base.transform.position.z);
            if (!this.notTrackingPlayer)
            {
                if (this.player.GetComponent<Rigidbody2D>().velocity.x > 0.5f)
                {
                    this.offsetX = PlayerController.speed / 2f;
                }
                if (this.player.GetComponent<Rigidbody2D>().velocity.x < -0.5f)
                {
                    this.offsetX = -PlayerController.speed / 2f;
                }
            }
        }
    }

    private IEnumerator DelayCamera(float WaitForAmount)
    {
        yield return new WaitForSeconds(WaitForAmount);
        this.active = true;
        yield break;
    }

    public Vector2 velocity;

    public bool notTrackingPlayer;

    public float smoothTimeY;

    public float smoothTimeX;

    public float offsetX;

    public float offsetY;

    public GameObject player;

    public float delay;

    public bool active;
}