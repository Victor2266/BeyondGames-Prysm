﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ratBehavior : MonoBehaviour
{
    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        speed = 2f;
        jumpForce = 4.5f;
        health = 50f;
        rb2d = base.GetComponent<Rigidbody2D>();
        anim = base.GetComponent<Animator>();

        StartCoroutine(RandJump());
    }

    private void FixedUpdate()
    {
        if (!isDead)
        {
            if (!LookingLeft)
            {
                base.transform.localScale = new Vector3(-1f, base.transform.localScale.y, base.transform.localScale.z);
            }
            else if (LookingLeft)
            {
                base.transform.localScale = new Vector3(1f, base.transform.localScale.y, base.transform.localScale.z);
            }
            if ( Mathf.Abs(rb2d.velocity.x) <= speed)
            {
                rb2d.velocity = new Vector2(moveHorizontal, rb2d.velocity.y);
            }
        }
        if (IsGrounded())
        {
            if (moveHorizontal > 0f)
            {
                if (!isDead)
                {
                    moveHorizontal -= 0.1f;
                }
            }
            else if (moveHorizontal < 0f && !isDead)
            {
                moveHorizontal += 0.1f;
            }
        }
        if (IsGrounded() && isDead)
        {
            base.StartCoroutine(FreezeInPlace());
        }
    }

    private IEnumerator FreezeInPlace()
    {
        yield return new WaitForSeconds(0.5f);
        if (IsGrounded() && isDead)
        {
            base.gameObject.GetComponent<CapsuleCollider2D>().enabled = false;
            rb2d.isKinematic = true;
            rb2d.velocity = new Vector2(0f, 0f);
        }
        yield break;
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag == "Player" && IsGrounded() && !isDead)
        {
            anim.SetTrigger("running");
            if (rb2d.position.x > collision.attachedRigidbody.position.x)
            {
                LookingLeft = true;
                moveHorizontal = -1f * speed;
            }
            else
            {
                LookingLeft = false;
                moveHorizontal = 1f * speed;
            }

            if (2 == Random.Range(1, 50))
            {
                StartCoroutine(RandJump());
            }
        }

        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player" && IsGrounded() && !isDead)
        {
            anim.SetTrigger("running");
            if (!LookingLeft)
            {
                rb2d.velocity = new Vector2(rb2d.velocity.x, 1f * jumpForce);
            }
            else if (LookingLeft)
            {
                rb2d.velocity = new Vector2(rb2d.velocity.x, 1f * jumpForce);
            }
            
        }
    }
    private IEnumerator RandJump()
    {
        yield return new WaitForSeconds(4);
        rayDirection = player.transform.position - transform.position;
        Physics2D.RaycastNonAlloc(transform.position, rayDirection, hit);
        if (hit[1].collider.name == "Player" && IsGrounded() && !isDead)
        {
            if (!LookingLeft)
            {
                rb2d.velocity = new Vector2(rb2d.velocity.x * 1.5f, 1f * jumpForce);
            }
            else if (LookingLeft)
            {
                rb2d.velocity = new Vector2(rb2d.velocity.x * 1.5f, 1f * jumpForce);
            }
        }
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player" && !isDead)
        {
            collision.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(rb2d.velocity.x * 10f, rb2d.velocity.y * 2f);
            player.SendMessage("TakeDamage", 20);
            anim.SetTrigger("attacking");
            return;
        }
    }

    private bool IsGrounded()
    {
        Vector2 origin = base.transform.position;
        origin.y -= 1.1f;
        return Physics2D.Raycast(origin, -Vector2.up, 0.005f);
    }

    public void TakeDamage(float amount)
    {
        health -= amount;
        anim.SetTrigger("hurt");
        if (health <= 0f && !isDead)
        {
            Death();
        }
    }

    private void Death()
    {
        isDead = true;
        clone = UnityEngine.Object.Instantiate<GameObject>(HealOrb, base.transform.position, base.transform.rotation);
        base.gameObject.GetComponentInChildren<Light>().enabled = false;
        anim.SetTrigger("dead");
        anim.SetBool("FullyDead", true);
    }

    public float speed;

    public float jumpForce;

    public float health;

    public GameObject player;

    private Rigidbody2D rb2d;

    private Animator anim;

    public bool LookingLeft;

    private bool isDead;

    private float moveHorizontal;

    private GameObject clone;

    public GameObject HealOrb;

    private RaycastHit2D[] hit = new RaycastHit2D[2];

    private Vector3 rayDirection;
}