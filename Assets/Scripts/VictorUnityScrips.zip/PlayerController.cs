﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{

    public static int MaxMana = 100; //the mana cap for your mana, upgrades change it

    public static int MaxHealth = 100; //health cap, it changes with upgrades

    public static float cameraSize = 3f;//camera size, these are public static because they change

    public static int Lives = 1;//number of lives, changes

    public static float speed = 3f;//max speed, changes

    private GameObject clone;//this game object contains the bullet, to position and impart velocity on it

    public float jumpForce;//how high the player can jump

    public float fallMultiplier = 2.5f;// the gravity on a high jump is greater

    public float lowJumpMultiplier = 2f;//lower gravity for low jump

    private Rigidbody2D rb2d;// ridgidbody for physics

    private Animator anim;//animation controller

    public GameObject Camera;//camera reference 

    private bool Flinch;//when the skeleton hits the player the player will flinch

    public Text LivesUI;//this is the text number for the lives in the ui

    public Slider health;//this is the health slider in ui

    public float currentHealth;//current health of player

    public Slider mana;//slider for mana in UI

    public int currentMana;//current mana player has

    private int ManaCost;//cost of the weapon the player is using in mana

    public GameObject transition;//the black transition object

    public static bool isDead;//if the player is dead

    private bool isDying;//if the player has 0 health and is dying

    public GameObject CompassOBJ;//compass obj points to goal

    private int charges = 1;//how many times the bullet shoots out

    private float timeStamp;//this calculates delta time for the cooldown of weapons

    private float coolDownPeriod;//cooldown val for weapons

    public int weapon;//weapon number

    public GameObject attack;//actual weapon prefab

    private float attackVelo;//velocity of weapon

    public GameObject weap1;//weapon prefabs

    public GameObject weap2;

    public GameObject weap3;

    public GameObject weap4;

    public GameObject weap5;

    public GameObject weap6;

    public GameObject weap7;

    public GameObject weap8;

    public GameObject weap9;

    public GameObject weap10;

    public GameObject weap11;

    public GameObject weap12;

    public GameObject weap13;

    public GameObject weap14;

    public GameObject ChargeIndicator;//the particle system when you use a charged shot

    public static int[] Chargeable = new int[14];//array keeps track of which charged shots you've unlocked
    public GameObject Orb;

    private CameraController OrbPosition;

    public GameObject gasPuff;
    private GameObject clone2;
    public GameObject redFlash;

    private void Start()
    {
        OrbPosition = Orb.GetComponent<CameraController>();

        SetWeap();
        ManaCost = 0;
        rb2d = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        RectTransform component = health.GetComponent<RectTransform>();
        component.sizeDelta = new Vector2((float)PlayerController.MaxHealth, component.sizeDelta.y);
        health.maxValue = (float)PlayerController.MaxHealth;
        RectTransform component2 = mana.GetComponent<RectTransform>();
        component2.sizeDelta = new Vector2((float)PlayerController.MaxMana, component2.sizeDelta.y);
        mana.maxValue = (float)PlayerController.MaxMana;
        currentHealth = health.maxValue;
        currentMana = (int)mana.maxValue;
        Camera.GetComponent<Camera>().orthographicSize = PlayerController.cameraSize;
        PlayerController.speed = PlayerController.speed;
    }

    private bool IsGrounded()
    {
        Vector2 origin = transform.position;
        origin.y -= 0.6f;
        return Physics2D.Raycast(origin, -Vector2.up, 0.005f);
    }

    private void Update()
    {
        if (!isDying)
        {
            MoveUpdate();
            Shooting();
            Compass();
        }
        UpdateHealth();
        if (Input.GetButtonDown("Reset"))
        {
            TakeDamage(currentHealth);
        }
        if (Input.GetKeyDown(KeyCode.G))
        {
            Upgrade(0, 900);
            Upgrade(1, 900);
            Upgrade(3, 1);
        }
    }

    public void SetWeap()//optimize this later to only run when pressed
    {
        if (Input.GetButtonDown("Charge") && PlayerController.Chargeable[weapon - 1] == weapon)
        {
            if (weapon <= 7)
            {
                ChargeIndicator.SetActive(true);
                weapon += 7;
            }
            else if (weapon >= 8)
            {
                ChargeIndicator.SetActive(false);
                weapon -= 7;
            }
        }
        if (weapon == 3)
        {
            attackVelo = 12f;
            attack = weap3;
            ManaCost = 10;
            coolDownPeriod = 0.5f;
        }
        if (weapon == 4)
        {
            attackVelo = 4f;
            attack = weap4;
            ManaCost = 5;
            coolDownPeriod = 0.2f;
        }
        if (weapon == 10)
        {
            attackVelo = 18f;
            attack = weap10;
            ManaCost = 33;
            coolDownPeriod = 2f;
        }
        if (weapon == 11)
        {
            attackVelo = 3f;
            attack = weap11;
            ManaCost = 20;
            coolDownPeriod = 1f;
        }
    }

    public void Shooting()
    {
        SetWeap();
        if (timeStamp <= Time.time)
        {
            if ((Input.GetButtonDown("Horizontal Shooting") || Input.GetButtonDown("Vertical Shooting")) && charges == 1 && currentMana - ManaCost >= 0)
            {
                clone = Instantiate(attack, transform.position, transform.rotation);
                currentMana -= ManaCost;
                charges = 0;
                if (weapon < 8)
                {
                    clone.GetComponent<projectileController>().Primed = false;
                }
            }
            if (charges == 0)
            {
                if (Input.GetButton("Horizontal Shooting") || Input.GetButton("Vertical Shooting"))
                {
                    if (Input.GetAxisRaw("Horizontal Shooting") > 0f)
                    {
                        Vector2 v = new Vector2(transform.position.x + 0.5f, transform.position.y);
                        clone.transform.position = new Vector3 (v.x,v.y, clone.transform.position.z);
                        clone.GetComponent<Rigidbody2D>().velocity = new Vector2(attackVelo, clone.GetComponent<Rigidbody2D>().velocity.y);

                        OrbPosition.offsetX = 0.5f;
                        OrbPosition.offsetY = -1.5f;
                    }
                    if (Input.GetAxisRaw("Horizontal Shooting") < 0f)
                    {
                        Vector2 v2 = new Vector2(transform.position.x - 0.5f, transform.position.y);
                        clone.transform.position = new Vector3(v2.x, v2.y, clone.transform.position.z);
                        clone.GetComponent<Rigidbody2D>().velocity = new Vector2(-attackVelo, clone.GetComponent<Rigidbody2D>().velocity.y);

                        OrbPosition.offsetX = -0.5f;
                        OrbPosition.offsetY = -1.5f;
                    }
                    if (Input.GetAxisRaw("Vertical Shooting") > 0f)
                    {
                        Vector2 v3 = new Vector2(transform.position.x, transform.position.y + 0.5f);
                        clone.transform.position = new Vector3(v3.x, v3.y, clone.transform.position.z);
                        clone.GetComponent<Rigidbody2D>().velocity = new Vector2(clone.GetComponent<Rigidbody2D>().velocity.x, attackVelo);

                        OrbPosition.offsetX = 0;
                        OrbPosition.offsetY = -1f;
                    }
                    if (Input.GetAxisRaw("Vertical Shooting") < 0f)
                    {
                        Vector2 v4 = new Vector2(transform.position.x, transform.position.y - 0.5f);
                        clone.transform.position = new Vector3(v4.x, v4.y, clone.transform.position.z);
                        clone.GetComponent<Rigidbody2D>().velocity = new Vector2(clone.GetComponent<Rigidbody2D>().velocity.x, -attackVelo);

                        OrbPosition.offsetX = 0;
                        OrbPosition.offsetY = -2f;
                    }
                    if (Mathf.Abs(clone.GetComponent<Rigidbody2D>().velocity.x) == Mathf.Abs(clone.GetComponent<Rigidbody2D>().velocity.y))
                    {
                        clone.GetComponent<Rigidbody2D>().velocity = new Vector2(clone.GetComponent<Rigidbody2D>().velocity.x * 0.7071f, clone.GetComponent<Rigidbody2D>().velocity.y * 0.7071f);
                    }
                    
                }
                if (Input.GetButtonUp("Horizontal Shooting") || Input.GetButtonUp("Vertical Shooting"))
                {
                    timeStamp = Time.time + coolDownPeriod;
                    charges = 1;
                    clone.GetComponent<projectileController>().Primed = true;
                }
            }
            else if (timeStamp + 2f <= Time.time)
            {
                OrbPosition.offsetX = 0.5f;
                OrbPosition.offsetY = -1f;
            }
        }
    }

    public void TakeDamage(float amount)
    {
        redFlash.SetActive(true);
        currentHealth -= amount;
        if (currentHealth <= 0f && !PlayerController.isDead)
        {
            StartCoroutine(DeathDelay(6f));
        }
    }

    public void UpdateHealth()
    {
        LivesUI.text = PlayerController.Lives.ToString();
        if (currentHealth < health.value)
        {
            health.value -= 1f;
        }
        if ((float)currentMana < mana.value)
        {
            mana.value -= 1f;
        }
        if (currentHealth > health.value)
        {
            health.value += 1f;
        }
        if ((float)currentMana > mana.value)
        {
            mana.value += 1f;
        }
    }

    public void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag == "magicItem" && currentMana < PlayerController.MaxMana)
        {
            currentMana += 2;
        }
        if (collision.tag == "healthItem" && currentHealth < (float)PlayerController.MaxHealth)
        {
            currentHealth += 2f;
        }
        if (collision.tag == "Heal15")
        {
            collision.gameObject.SetActive(false);
            for (int i = 15; i > 0; i--)
            {
                if (currentHealth < (float)PlayerController.MaxHealth)
                {
                    currentHealth += 1f;
                }
            }
        }
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "UpgradeHealth")
        {
            int amount = collision.GetComponent<UpgradeItem>().amount;
            collision.gameObject.SetActive(false);
            Upgrade(0, amount);
        }
        if (collision.tag == "UpgradeMana")
        {
            int amount2 = collision.GetComponent<UpgradeItem>().amount;
            Upgrade(1, amount2);
        }
        if (collision.tag == "UpgradeZoom")
        {
            int amount3 = collision.GetComponent<UpgradeItem>().amount;
            collision.gameObject.SetActive(false);
            Upgrade(2, amount3);
        }
        if (collision.tag == "UpgradeSpeed")
        {
            int amount4 = collision.GetComponent<UpgradeItem>().amount;
            collision.gameObject.SetActive(false);
            Upgrade(3, amount4);
        }
    }

    public void SliderWeapon(int weapNum)
    {
        weapon = weapNum;
    }

    private IEnumerator DeathDelay(float interval)
    {
        transition.SetActive(true);
        if (!isDying)
        {
            anim.SetTrigger("Die");
            isDying = true;
        }
        yield return new WaitForSeconds(interval);
        PlayerController.MaxHealth = 100;
        PlayerController.MaxMana = 100;
        PlayerController.isDead = true;
        yield break;
    }

    private IEnumerator JumpStretch()
    {
        for(int i = 0; i < 10; i++)
        {
            yield return new WaitForSeconds(0.0001f);
            GetComponent<SpriteRenderer>().size = new Vector2(GetComponent<SpriteRenderer>().size.x - 0.02f, GetComponent<SpriteRenderer>().size.y + 0.02f);
        }
        for (int i = 0; i < 10; i++)
        {
            //yield return new WaitForSeconds(0.00001f);
            GetComponent<SpriteRenderer>().size = new Vector2(GetComponent<SpriteRenderer>().size.x + 0.02f, GetComponent<SpriteRenderer>().size.y - 0.02f);
        }
        yield break;
    }
    public void MoveUpdate()
    {
        if (rb2d.velocity.x > 0.5f)
        {
            rb2d.velocity = new Vector2(rb2d.velocity.x - 0.3f, rb2d.velocity.y);
        }
        else if (rb2d.velocity.x < -0.5f)
        {
            rb2d.velocity = new Vector2(rb2d.velocity.x + 0.3f, rb2d.velocity.y);
        }
        if (Input.GetAxisRaw("Horizontal") > 0f && Mathf.Abs(rb2d.velocity.x) < PlayerController.speed && !Flinch)
        {
            anim.SetBool("LookingRight", true);
            anim.SetBool("Running", true);
            rb2d.velocity = new Vector2(PlayerController.speed, rb2d.velocity.y);
        }
        else if (Input.GetAxisRaw("Horizontal") < 0f && Mathf.Abs(rb2d.velocity.x) < PlayerController.speed && !Flinch)
        {
            anim.SetBool("LookingRight", false);
            anim.SetBool("Running", true);
            rb2d.velocity = new Vector2(-PlayerController.speed, rb2d.velocity.y);
        }
        else if (Mathf.Abs(rb2d.velocity.x) < 0.05f)
        {
            anim.SetBool("Running", false);
        }
        if (rb2d.velocity.y < 0f)
        {
            anim.SetBool("Jumping", false);
        }

        if (rb2d.velocity.y < 0f)
        {
            rb2d.velocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier - 1f) * Time.deltaTime;
        }
        else if (rb2d.velocity.y > 0f && !Input.GetKey(KeyCode.Space))
        {
            rb2d.velocity += Vector2.up * Physics2D.gravity.y * (lowJumpMultiplier - 1f) * Time.deltaTime;
        }
        if (Input.GetButtonDown("Jump") && IsGrounded())
        {
            if (rb2d.velocity.x == speed)
            {
                rb2d.velocity = new Vector2(rb2d.velocity.x * speed/2, rb2d.velocity.y);
            }
            else if (rb2d.velocity.x == -speed)
            {
                rb2d.velocity = new Vector2(rb2d.velocity.x * speed/2, rb2d.velocity.y);
            }
            rb2d.velocity = new Vector2(rb2d.velocity.x, jumpForce);
            anim.SetBool("Jumping", true);
            StartCoroutine(JumpStretch());
            Vector3 GasPos = new Vector3 (transform.position.x, transform.position.y - 0.4f, 0);
            clone2 = Instantiate(gasPuff, GasPos, transform.rotation);
        }
    }

    public void Flinching()
    {
        StartCoroutine(PauseAfterHit());
    }

    private IEnumerator PauseAfterHit()
    {
        Flinch = true;
        yield return new WaitForSeconds(0.2f);
        Flinch = false;
        yield break;
    }

    public void Upgrade(int type, int amount)
    {
        for (int i = amount; i > 0; i--)
        {
            if (type == 0)
            {
                PlayerController.MaxHealth++;
                currentHealth += 1f;
            }
            if (type == 1)
            {
                PlayerController.MaxMana++;
                currentMana++;
            }
            if (type == 2)
            {
                PlayerController.cameraSize += 0.4f;
                Camera.GetComponent<Camera>().orthographicSize = PlayerController.cameraSize;
            }
            if (type == 3)
            {
                PlayerController.speed += 0.5f;
            }
            RectTransform component = health.GetComponent<RectTransform>();
            component.sizeDelta = new Vector2((float)PlayerController.MaxHealth, component.sizeDelta.y);
            health.maxValue = (float)PlayerController.MaxHealth;
            RectTransform component2 = mana.GetComponent<RectTransform>();
            component2.sizeDelta = new Vector2((float)PlayerController.MaxMana, component2.sizeDelta.y);
            mana.maxValue = (float)PlayerController.MaxMana;
        }
    }

    public void Compass()
    {
        if (Input.GetButton("Compass"))
        {
            CompassOBJ.SetActive(true);
        }
        if (Input.GetButtonUp("Compass"))
        {
            CompassOBJ.SetActive(false);
        }
    }

}