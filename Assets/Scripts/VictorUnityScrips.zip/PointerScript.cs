﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointerScript : MonoBehaviour
{
    private void Start()
    {
    }

    private void Update()
    {
        this.xDiff = this.boss.transform.position.x - base.transform.position.x;
        this.yDiff = this.boss.transform.position.y - base.transform.position.y;
        this.XAngle = 57.29578f * Mathf.Atan(this.yDiff / this.xDiff);
        if (this.xDiff > 0f)
        {
            base.transform.eulerAngles = new Vector3(360f - this.XAngle, 90f, 0f);
        }
        if (this.xDiff < 0f)
        {
            base.transform.eulerAngles = new Vector3(180f - this.XAngle, 90f, 0f);
        }
        if (!this.boss.activeSelf)
        {
            this.boss.transform.position = new Vector2(this.xDest, this.yDest);
        }
    }

    public float xDest;

    public float yDest;

    private float xDiff;

    private float yDiff;

    private float XAngle;

    public GameObject boss;
}