﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManager : MonoBehaviour
{
    private void Start()
    {
        pos = player.GetComponent<Transform>();
        StartingHealth = PlayerController.MaxHealth;
        StartingMana = PlayerController.MaxMana;
        StartingSpeed = PlayerController.speed;
        StartingSize = PlayerController.cameraSize;
        StartingChargeable = PlayerController.Chargeable;
    }

    private void Update()
    {
        pos = player.transform;
        if (Input.anyKeyDown && !Input.GetMouseButton(0) && Level == 1)
        {
            base.StartCoroutine(trans());
            PlayerController.MaxHealth = 100;
            PlayerController.MaxMana = 100;
            PlayerController.cameraSize = 3f;
            PlayerController.speed = 3f;
            PlayerController.Chargeable = new int[14];
        }
        if (pos.position.y < -46f && Level == 2)
        {
            base.StartCoroutine(trans());
        }
        if (PlayerController.isDead)
        {
            if (PlayerController.Lives > 0)
            {
                UnityEngine.SceneManagement.SceneManager.LoadScene("Scene " + Level, LoadSceneMode.Single);
                PlayerController.isDead = false;
                PlayerController.Lives--;
                PlayerController.MaxHealth = StartingHealth;
                PlayerController.MaxMana = StartingMana;
                PlayerController.cameraSize = StartingSize;
                PlayerController.speed = StartingSpeed;
                PlayerController.Chargeable = StartingChargeable;
            }
            else
            {
                UnityEngine.SceneManagement.SceneManager.LoadScene("Scene " + 1, LoadSceneMode.Single);
                PlayerController.isDead = false;
                Level = 1;
            }
        }
    }

    private IEnumerator trans()
    {
        transition.SetActive(true);
        yield return new WaitForSeconds(4f);
        UnityEngine.SceneManagement.SceneManager.LoadScene("Scene " + (Level + 1), LoadSceneMode.Single);
        PlayerController.Lives++;
        Level++;
        StartingHealth = PlayerController.MaxHealth;
        StartingMana = PlayerController.MaxMana;
        StartingSpeed = PlayerController.speed;
        StartingSize = PlayerController.cameraSize;
        StartingChargeable = PlayerController.Chargeable;
        yield break;
    }

    public GameObject player;

    private Transform pos;

    public GameObject transition;

    public static int Level = 1;

    private static int StartingHealth;

    private static int StartingMana;

    private static float StartingSpeed;

    private static float StartingSize;

    private static int[] StartingChargeable = new int[14];
}
