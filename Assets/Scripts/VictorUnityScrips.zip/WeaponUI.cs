﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WeaponUI : MonoBehaviour
{

    public GameObject WeaponRedUI;
    public GameObject WeaponOrangeUI;
    public GameObject WeaponYellowUI;
    public GameObject WeaponGreenUI;
    public GameObject WeaponBlueUI;
    public GameObject WeaponIndigoUI;
    public GameObject WeaponVioletUI;
    public GameObject Slider;
    private RectTransform SliderUI;
    private RawImage SliderColour;
    public Vector2 velocity;
    public int TruePosition;
    private float posX;
    public GameObject Player;
    private PlayerController playerScript;
    public GameObject FillObj;
    private Image manaFillColor;
    public Color CurrentColor;
    private float sizeRefVelo;
    private float sliderYSize;

    private void Start()
    {
        manaFillColor = FillObj.GetComponent<Image>();
        SliderUI = Slider.GetComponent<RectTransform>();
        SliderColour = Slider.GetComponent<RawImage>();
        playerScript = Player.GetComponent<PlayerController>();

        TruePosition = -90;
        CurrentColor = new Color(0f, 1f, 0f, 1f);

    }

    private void Update()
    {
        if (Mathf.Abs(SliderUI.anchoredPosition.x - (float)TruePosition) > 0.01f)
        {
            posX = Mathf.SmoothDamp(SliderUI.anchoredPosition.x, (float)TruePosition, ref velocity.y, 0.2f);
            SliderColour.color = Color.Lerp(SliderColour.color, CurrentColor, 0.1f);
            SliderUI.anchoredPosition = new Vector2(posX, 0f);
            playerScript.ChargeIndicator.SetActive(false);

            manaFillColor.color = SliderColour.color;
        }

        if (Input.GetKey(KeyCode.Alpha1))
        {
            TruePosition = -180;
            CurrentColor = new Color(1f, 0f, 0f, 1f);
        }
        if (Input.GetKey(KeyCode.Alpha2))
        {
            TruePosition = -150;
            CurrentColor = new Color(1f, 0.5f, 0f, 1f);
        }
        if (Input.GetKey(KeyCode.Alpha3) && WeaponYellowUI.activeSelf == true)
        {
            playerScript.weapon = 3;
            TruePosition = -120;
            CurrentColor = new Color(1f, 1f, 0f, 1f);
        }
        if (Input.GetKey(KeyCode.Alpha4) && WeaponGreenUI.activeSelf == true)
        {
            playerScript.weapon = 4;
            TruePosition = -90;
            CurrentColor = new Color(0f, 1f, 0f, 1f);
        }
        if (Input.GetKey(KeyCode.Alpha5))
        {
            TruePosition = -60;
            CurrentColor = new Color(0.15f, 0.3f, 1f, 1f);
        }
        if (Input.GetKey(KeyCode.Alpha6))
        {
            TruePosition = -30;
            CurrentColor = new Color(0.5f, 0.25f, 1f, 1f);
        }
        if (Input.GetKey(KeyCode.Alpha7))
        {
            TruePosition = 0;
            CurrentColor = new Color(1f, 0.2f, 1f, 255f);


        }
        if(playerScript.weapon > 7)
        {
            sliderYSize = Mathf.SmoothDamp(SliderUI.sizeDelta.y, 90, ref sizeRefVelo, 0.2f);

            SliderUI.sizeDelta = new Vector2(30, sliderYSize);
        }
        else if (playerScript.weapon < 8)
        {
            sliderYSize = Mathf.SmoothDamp(SliderUI.sizeDelta.y, 60, ref sizeRefVelo, 0.2f);

            SliderUI.sizeDelta = new Vector2(30, sliderYSize);
        }
    }

}