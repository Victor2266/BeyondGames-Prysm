﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathTimer : MonoBehaviour
{
    private void Start()
    {
        if (trail)
        {
            trailRenderer = GetComponent<TrailRenderer>();
        }
        ticks = Time.time;
        timeend = Time.time + tickLimit;
        endValue = timeend - ticks;
    }

    private void Update()
    {
        if (ticks > timeend)
        {
            gameObject.SetActive(false);
        }
        else
        {
            ticks = Time.time;
        }
        if (shrinks)
        {
            gameObject.transform.localScale = new Vector2((timeend - ticks) / endValue, (timeend - ticks) / endValue);
            if (trail)
            {
                trailRenderer.widthMultiplier = (timeend - ticks) / endValue * widthOfBullet;
                trailRenderer.time = (timeend - ticks) / endValue * timeOfBullet;
            }
        }
    }

    public float ticks;

    public float tickLimit;

    public bool shrinks;

    public bool trail;

    public float widthOfBullet;

    public float timeOfBullet;

    private float timeend;

    private float endValue;

    private TrailRenderer trailRenderer;
}
